var express = require('express');
var router = express.Router();
var path = require('path');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/iets', function (req, res, next) {
   //verzenden van html 
    res.send("Welkom vanuit Express")

});

router.get('/html', function (req, res, next) {
    //verzenden van een volledige html file met zijn volledig ABSOLUUT path
    //gebruik niet de naam index.html of eenzelfde naam als een view
    res.sendFile(path.join(__dirname,"../public","/index2.html"));
});

module.exports = router;
