var express = require('express');
var router = express.Router();
let users = require('../data/users.json');

/* GET users listing. 
/users/
*/
router.get('/', function(req, res, next) {
  //res.send('respond with a resource');
    res.render('users/index', {title: "De gebruikers", users});

});

router.get('/:name', (req, res, next) => {
    let user = users[req.params.name];
    //Het web => valideer INPUTS !!!!
    if (user) {
        res.render('users/details', {title: "Details", user}  )
    } else {
        next();
    }

})

module.exports = router;
